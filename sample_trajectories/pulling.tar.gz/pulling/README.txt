Source directory: `$SCRATCH/bundle_pulling/moving/motors_k3/5_5/k1000/0.1/10_0.01_100`
