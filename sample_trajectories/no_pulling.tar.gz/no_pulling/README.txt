Source: `$SCRATCH/phase_diagram_full_trjs/v1.2/k3/trj0`
